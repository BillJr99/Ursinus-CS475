import random

# Constants
TOTAL_PACKETS = 10  # Number of packets to be sent
WINDOW_SIZE = 4  # Number of packets in-flight at a time
TIMEOUT = 5  # Timeout duration for retransmission
USE_SELECTIVE_REPEAT = True  # False = Go-Back-N mode

# Simulation state tracking
sent_packets = []
acknowledged = [False] * TOTAL_PACKETS  # Track acknowledged packets
timeouts = {}  # Timeout tracker for retransmissions
sender_base = 0
next_seq_num = 0
output_log = []
time = 0  # Simulation time counter

while sender_base < TOTAL_PACKETS:
    # Send packets within the window limit
    while next_seq_num < sender_base + WINDOW_SIZE and next_seq_num < TOTAL_PACKETS:
        if next_seq_num not in sent_packets:
            sent_packets.append(next_seq_num)
            timeouts[next_seq_num] = time + TIMEOUT  # Set timeout
            output_log.append(
                f"[{time}] Sender: Sending packet {next_seq_num}")
        next_seq_num += 1

    # Receiver processes packets and ACKs (with possible loss)
    if sender_base in sent_packets:
        if random.random() < 0.80:  # 80% chance packet is received
            if random.random() < 0.85:  # 85% chance ACK is received
                output_log.append(
                    f"[{time}] Receiver: Acknowledging packet {sender_base}")
                acknowledged[sender_base] = True
                sender_base += 1  # Go-Back-N: Slide window only on base acknowledgment
            else:
                output_log.append(
                    f"[{time}] Receiver: Lost ACK for packet {sender_base}")
        else:
            output_log.append(f"[{time}] Receiver: Lost packet {sender_base}")

    # Handle timeouts and retransmissions
    if sender_base in sent_packets and not acknowledged[
            sender_base] and time >= timeouts[sender_base]:
        output_log.append(
            f"[{time}] Sender: Timeout! Retransmitting from packet {sender_base}"
        )
        next_seq_num = sender_base  # Reset sender window to resend from the base
        sent_packets = sent_packets[sent_packets.index(
            sender_base):]  # Keep only unacked packets
        timeouts[
            sender_base] = time + TIMEOUT  # Reset timeout for retransmission

    # Increment simulation time
    time += 1

# Print output log
output_text = "\n".join(output_log)
print(output_text)
