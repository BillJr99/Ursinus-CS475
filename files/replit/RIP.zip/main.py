import numpy as np


def get_edges(graph):
  edges = []

  for i in range(len(graph)):
    for j in range(len(graph[i])):
      edges.append((i, j, graph[i][j]))

  return edges


G = [[0, 7, 9, np.inf, np.inf, 14], [7, 0, 10, 15, np.inf, np.inf],
     [9, 10, 0, 11, np.inf, 2], [np.inf, 15, 11, 0, 6, np.inf],
     [np.inf, np.inf, np.inf, 6, 0, 9], [14, np.inf, 2, np.inf, 9, 0]]

N = len(G)
source = 0

distance = [np.inf] * N
prev = [-1] * N
distance[source] = 0
edges = get_edges(G)

for i in range(N):
  for (u, v, w) in edges:
    dist = distance[u] + w
    if dist < distance[v]:
      distance[v] = dist
      prev[v] = u

print(list(zip(distance, prev)))
