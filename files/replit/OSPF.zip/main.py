import numpy as np


# pick the smallest element in values whose index is in indices
def minidx(values, indices):
  minidx = None
  minval = None

  for i in range(len(indices)):
    idx = indices[i]

    if minval is None:
      minval = values[idx]
      minidx = i
    elif values[idx] < minval:
      minval = values[idx]
      minidx = i

  print("Minidx of {} for indices {} is {}".format(values, indices, minidx))
  return minidx


Q = []

G = [[0, 7, 9, np.inf, np.inf, 14], [7, 0, 10, 15, np.inf, np.inf],
     [9, 10, 0, 11, np.inf, 2], [np.inf, 15, 11, 0, 6, np.inf],
     [np.inf, np.inf, np.inf, 6, 0, 9], [14, np.inf, 2, np.inf, 9, 0]]

source = 0

distance = []
prev = []

for i in range(len(G[source])):
  distance.append(np.inf)
  prev.append(-1)
  Q.append(i)

distance[source] = 0

while len(Q) > 0:
  u_idx = minidx(distance, Q)
  u = Q.pop(u_idx)

  print("Considering node {}".format(u))

  for i in range(len(G[u])):
    v = G[u][i]

    if v != np.inf and v != 0:
      print("Trying neighbor {} at position {} of {}".format(v, i, G[u]))

      dist = distance[u] + G[u][i]

      if dist < distance[i]:
        distance[i] = dist
        prev[i] = u

print(list(zip(distance, prev)))

# Node 0's routing table is [(0, -1), (7, 0), (9, 0), (20, 2), (20, 5), (11, 2)] - printing the distance first, and then the immediately prior node to the destination
# Node 0 should go through node 5 to get to node 4, but how should it go through node 5?  Define this recursively.